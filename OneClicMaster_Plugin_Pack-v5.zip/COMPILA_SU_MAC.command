#!/bin/bash
cd "$(dirname "$0")"
echo "========================================================"
echo "  ONE CLIC MASTER (By BR1) - AUTO-BUILDER MACOS (VST3 & AU)"
echo "========================================================"
echo "[1/2] Configurazione CMake e download automatico JUCE 7..."
cmake -B build -DCMAKE_BUILD_TYPE=Release
echo "[2/2] Compilazione di OneClicMaster.vst3 e OneClicMaster.component..."
cmake --build build --config Release
echo "========================================================"
echo "  COMPILAZIONE COMPLETATA!"
echo "  Trovi i plugin finiti dentro:"
echo "  build/OneClicMaster_artefacts/Release/VST3/OneClicMaster.vst3"
echo "  build/OneClicMaster_artefacts/Release/AU/OneClicMaster.component"
echo "========================================================"
read -p "Premi Invio per chiudere..."
