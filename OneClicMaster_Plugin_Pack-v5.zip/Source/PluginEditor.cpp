#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <BinaryData.h>

OneClicMasterAudioProcessorEditor::OneClicMasterAudioProcessorEditor (OneClicMasterAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setSize (540, 380);

    if (audioProcessor.customLogoPath.isNotEmpty())
    {
        juce::File customFile (audioProcessor.customLogoPath);
        if (customFile.existsAsFile())
            brandLogo = juce::ImageFileFormat::loadFrom (customFile);
    }

    if (!brandLogo.isValid())
    {
        brandLogo = juce::ImageCache::getFromMemory (BinaryData::logo_png, BinaryData::logo_pngSize);
    }

    presetSelector.addItemList ({
        "1. Tech House Club Roller",
        "2. EDM & Progressive BigRoom",
        "3. American Trap 808 Knock",
        "4. UK / NY Mafia Trap Dark",
        "5. Universal Streaming Master"
    }, 1);
    addAndMakeVisible (presetSelector);
    presetAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        audioProcessor.apvts, "PRESET_ID", presetSelector);

    oneClicButton.setClickingTogglesState (true);
    oneClicButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff272936));
    oneClicButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xffff6b00));
    oneClicButton.onClick = [this]()
    {
        if (oneClicButton.getToggleState())
            audioProcessor.triggerOneClickAnalyze();
    };
    addAndMakeVisible (oneClicButton);
    masterActiveAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, "MASTER_ACTIVE", oneClicButton);

    intensitySlider.setSliderStyle (juce::Slider::LinearHorizontal);
    intensitySlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 60, 22);
    addAndMakeVisible (intensitySlider);
    intensityAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, "INTENSITY", intensitySlider);

    statusLabel.setJustificationType (juce::Justification::centred);
    statusLabel.setColour (juce::Label::textColourId, juce::Colours::lightgrey);
    addAndMakeVisible (statusLabel);

    startTimerHz (20);
}

void OneClicMasterAudioProcessorEditor::mouseDown (const juce::MouseEvent& event)
{
    if (logoBounds.contains (event.getPosition()))
        loadCustomLogoFromFile();
}

void OneClicMasterAudioProcessorEditor::loadCustomLogoFromFile()
{
    logoFileChooser = std::make_unique<juce::FileChooser> (
        "Seleziona il tuo Logo (PNG o JPG)",
        juce::File::getSpecialLocation (juce::File::userDesktopDirectory),
        "*.png;*.jpg;*.jpeg");

    auto folderChooserFlags = juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;

    logoFileChooser->launchAsync (folderChooserFlags, [this] (const juce::FileChooser& chooser)
    {
        juce::File chosenFile = chooser.getResult();
        if (chosenFile.existsAsFile())
        {
            juce::Image loadedImg = juce::ImageFileFormat::loadFrom (chosenFile);
            if (loadedImg.isValid())
            {
                brandLogo = loadedImg;
                audioProcessor.customLogoPath = chosenFile.getFullPathName();
                repaint();
            }
        }
    });
}

void OneClicMasterAudioProcessorEditor::timerCallback()
{
    float inRms    = audioProcessor.currentInputRmsDb.load();
    float outPeak  = audioProcessor.currentOutputPeakDb.load();
    float autoTrim = audioProcessor.autoCalibratedTrimDb.load();

    juce::String text = "IN RMS: " + juce::String (inRms, 1) + " dB   |   "
                      + "AUTO-GAIN: " + (autoTrim >= 0 ? "+" : "") + juce::String (autoTrim, 1) + " dB   |   "
                      + "OUT PEAK: " + juce::String (outPeak, 1) + " dBFS";
    statusLabel.setText (text, juce::dontSendNotification);
}

void OneClicMasterAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff111217));

    g.setColour (juce::Colour (0xff181a22));
    g.fillRoundedRectangle (20.0f, 10.0f, static_cast<float>(getWidth() - 40), 52.0f, 10.0f);
    g.setColour (juce::Colour (0xff272936));
    g.drawRoundedRectangle (20.0f, 10.0f, static_cast<float>(getWidth() - 40), 52.0f, 10.0f, 1.2f);

    if (brandLogo.isValid())
    {
        g.drawImageWithin (brandLogo,
                           logoBounds.getX(), logoBounds.getY(),
                           logoBounds.getWidth(), logoBounds.getHeight(),
                           juce::RectanglePlacement::centred | juce::RectanglePlacement::onlyReduceInSize);
    }
    else
    {
        g.setColour (juce::Colour (0xffff6b00));
        g.drawRoundedRectangle (logoBounds.toFloat(), 8.0f, 2.0f);
    }

    g.setColour (juce::Colours::white);
    g.setFont (juce::Font (22.0f, juce::Font::bold));
    g.drawText ("ONE CLIC MASTER", 92, 18, 235, 36, juce::Justification::centredLeft);

    juce::Rectangle<float> br1Badge (332.0f, 23.0f, 78.0f, 26.0f);
    g.setColour (juce::Colour (0x26ff6b00));
    g.fillRoundedRectangle (br1Badge, 6.0f);
    g.setColour (juce::Colour (0xffff6b00));
    g.drawRoundedRectangle (br1Badge, 6.0f, 1.5f);
    g.setFont (juce::Font (13.5f, juce::Font::bold));
    g.drawText ("By BR1", br1Badge.toNearestInt(), juce::Justification::centred);

    g.setColour (juce::Colours::grey);
    g.setFont (14.0f);
    g.drawText ("Preset Mastering:", 40, 82, 140, 28, juce::Justification::centredLeft);
    g.drawText ("Intensita Catena:", 40, 270, 140, 28, juce::Justification::centredLeft);
}

void OneClicMasterAudioProcessorEditor::resized()
{
    presetSelector.setBounds (185, 82, 315, 30);
    oneClicButton.setBounds  (120, 134, 300, 112);
    intensitySlider.setBounds(185, 270, 315, 30);
    statusLabel.setBounds    (20, 325, getWidth() - 40, 30);
}
