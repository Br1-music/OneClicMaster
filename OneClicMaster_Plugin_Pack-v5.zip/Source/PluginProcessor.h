#pragma once
#include <JuceHeader.h>

struct MasteringPreset
{
    juce::String name;
    float lowShelfGainDb;     // 75 Hz Sub/Low Punch
    float midPeakGainDb;      // 1200 Hz Presence / Boxiness Cut
    float highShelfGainDb;    // 10000 Hz Air & Hi-Hats
    float compThresholdDb;
    float compRatio;
    float compAttackMs;
    float compReleaseMs;
    float saturationDrive;    // Soft-clipper harmonic drive (tanh)
    float stereoWidth;        // Mid/Side width factor
    float targetLoudnessDb;   // Pre-limiter push
};

class OneClicMasterAudioProcessor : public juce::AudioProcessor
{
public:
    OneClicMasterAudioProcessor();
    ~OneClicMasterAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "OneClicMaster"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return static_cast<int>(presets.size()); }
    int getCurrentProgram() override { return currentPresetIndex; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override { return presets[index].name; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    void triggerOneClickAnalyze();

    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    std::atomic<float> currentInputRmsDb { -60.0f };
    std::atomic<float> currentOutputPeakDb { -60.0f };
    std::atomic<float> autoCalibratedTrimDb { 0.0f };

    juce::String customLogoPath;

private:
    void updateDspParameters();

    double currentSampleRate = 44100.0;
    int currentPresetIndex = 0;
    std::vector<MasteringPreset> presets;

    using FilterBand = juce::dsp::ProcessorDuplicator<
        juce::dsp::IIR::Filter<float>,
        juce::dsp::IIR::Coefficients<float>>;

    FilterBand subCutFilter;
    FilterBand lowShelfFilter;
    FilterBand midPeakFilter;
    FilterBand highShelfFilter;

    juce::dsp::Compressor<float> busCompressor;
    juce::dsp::Limiter<float> brickwallLimiter;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (OneClicMasterAudioProcessor)
};
