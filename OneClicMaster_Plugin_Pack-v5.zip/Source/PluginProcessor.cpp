#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

OneClicMasterAudioProcessor::OneClicMasterAudioProcessor()
    : AudioProcessor (BusesProperties()
                      .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMETERS", createParameterLayout())
{
    presets = {
        { "1. Tech House Club Roller",    2.6f, -1.0f,  2.0f, -17.5f, 3.2f, 18.0f,  85.0f, 1.32f, 1.16f, 7.0f },
        { "2. EDM & Progressive BigRoom", 2.4f, -0.6f,  2.6f, -18.0f, 3.5f, 15.0f,  95.0f, 1.38f, 1.25f, 7.8f },
        { "3. American Trap 808 Knock",   3.4f, -1.4f,  2.2f, -17.0f, 3.0f, 22.0f, 105.0f, 1.48f, 1.12f, 6.8f },
        { "4. UK / NY Mafia Trap Dark",   3.0f, -1.8f,  1.2f, -16.5f, 3.4f, 16.0f,  90.0f, 1.52f, 1.10f, 7.2f },
        { "5. Universal Streaming Master",1.2f,  0.0f,  1.5f, -16.0f, 2.0f, 25.0f, 150.0f, 1.15f, 1.08f, 4.5f }
    };
}

juce::AudioProcessorValueTreeState::ParameterLayout OneClicMasterAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        "MASTER_ACTIVE", "One Clic Master Active", true));

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        "PRESET_ID", "Preset",
        juce::StringArray {
            "1. Tech House Club Roller",
            "2. EDM & Progressive BigRoom",
            "3. American Trap 808 Knock",
            "4. UK / NY Mafia Trap Dark",
            "5. Universal Streaming Master"
        }, 0));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "INTENSITY", "Master Intensity",
        juce::NormalisableRange<float> (0.0f, 2.0f, 0.01f), 1.0f));

    return { params.begin(), params.end() };
}

void OneClicMasterAudioProcessor::setCurrentProgram (int index)
{
    if (index >= 0 && index < static_cast<int>(presets.size()))
    {
        currentPresetIndex = index;
        if (auto* param = apvts.getParameter ("PRESET_ID"))
            param->setValueNotifyingHost (param->convertTo0to1 (static_cast<float>(index)));
    }
}

void OneClicMasterAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;

    juce::dsp::ProcessSpec spec;
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = static_cast<juce::uint32> (samplesPerBlock);
    spec.numChannels = static_cast<juce::uint32> (getTotalNumOutputChannels());

    subCutFilter.prepare (spec);
    lowShelfFilter.prepare (spec);
    midPeakFilter.prepare (spec);
    highShelfFilter.prepare (spec);

    busCompressor.prepare (spec);
    brickwallLimiter.prepare (spec);

    brickwallLimiter.setThreshold (-0.3f);
    brickwallLimiter.setRelease (40.0f);

    updateDspParameters();
}

bool OneClicMasterAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void OneClicMasterAudioProcessor::updateDspParameters()
{
    int presetIdx = static_cast<int> (apvts.getRawParameterValue ("PRESET_ID")->load());
    float intensity = apvts.getRawParameterValue ("INTENSITY")->load();

    currentPresetIndex = juce::jlimit (0, static_cast<int>(presets.size()) - 1, presetIdx);
    const auto& p = presets[currentPresetIndex];

    *subCutFilter.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass (
        currentSampleRate, 30.0, 0.707f);

    *lowShelfFilter.state = *juce::dsp::IIR::Coefficients<float>::makeLowShelf (
        currentSampleRate, 75.0, 0.707f, juce::Decibels::decibelsToGain (p.lowShelfGainDb * intensity));

    *midPeakFilter.state = *juce::dsp::IIR::Coefficients<float>::makePeakFilter (
        currentSampleRate, 1200.0, 0.8f, juce::Decibels::decibelsToGain (p.midPeakGainDb * intensity));

    *highShelfFilter.state = *juce::dsp::IIR::Coefficients<float>::makeHighShelf (
        currentSampleRate, 10000.0, 0.707f, juce::Decibels::decibelsToGain (p.highShelfGainDb * intensity));

    busCompressor.setThreshold (p.compThresholdDb);
    busCompressor.setRatio (1.0f + (p.compRatio - 1.0f) * intensity);
    busCompressor.setAttack (p.compAttackMs);
    busCompressor.setRelease (p.compReleaseMs);
}

void OneClicMasterAudioProcessor::triggerOneClickAnalyze()
{
    float inRms = currentInputRmsDb.load();
    if (inRms > -50.0f)
    {
        float desiredInputRms = -16.0f;
        float neededCorrection = juce::jlimit (-6.0f, 9.0f, desiredInputRms - inRms);
        autoCalibratedTrimDb.store (neededCorrection);
    }
    apvts.getParameter ("MASTER_ACTIVE")->setValueNotifyingHost (1.0f);
}

void OneClicMasterAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();

    if (numChannels < 2 || numSamples == 0)
        return;

    float rmsL = buffer.getRMSLevel (0, 0, numSamples);
    float rmsR = buffer.getRMSLevel (1, 0, numSamples);
    float avgRmsDb = juce::Decibels::gainToDecibels ((rmsL + rmsR) * 0.5f + 1e-6f);
    currentInputRmsDb.store (avgRmsDb);

    bool masterActive = apvts.getRawParameterValue ("MASTER_ACTIVE")->load() > 0.5f;
    if (!masterActive)
    {
        currentOutputPeakDb.store (juce::Decibels::gainToDecibels (buffer.getMagnitude (0, numSamples) + 1e-6f));
        return;
    }

    updateDspParameters();
    const auto& p = presets[currentPresetIndex];
    float intensity = apvts.getRawParameterValue ("INTENSITY")->load();

    juce::dsp::AudioBlock<float> block (buffer);
    juce::dsp::ProcessContextReplacing<float> context (block);

    subCutFilter.process (context);
    lowShelfFilter.process (context);
    midPeakFilter.process (context);
    highShelfFilter.process (context);
    busCompressor.process (context);

    float width = 1.0f + (p.stereoWidth - 1.0f) * intensity;
    float drive = 1.0f + (p.saturationDrive - 1.0f) * intensity;
    float totalGainBoostDb = (p.targetLoudnessDb * intensity) + autoCalibratedTrimDb.load();
    float linearBoost = juce::Decibels::decibelsToGain (totalGainBoostDb);

    auto* left  = buffer.getWritePointer (0);
    auto* right = buffer.getWritePointer (1);

    for (int i = 0; i < numSamples; ++i)
    {
        float mid  = 0.5f * (left[i] + right[i]);
        float side = 0.5f * (left[i] - right[i]) * width;

        float outL = (mid + side) * linearBoost;
        float outR = (mid - side) * linearBoost;

        if (drive > 1.01f)
        {
            float norm = 1.0f / std::tanh (drive);
            outL = std::tanh (outL * drive) * norm;
            outR = std::tanh (outR * drive) * norm;
        }

        left[i]  = outL;
        right[i] = outR;
    }

    brickwallLimiter.process (context);
    currentOutputPeakDb.store (juce::Decibels::gainToDecibels (buffer.getMagnitude (0, numSamples) + 1e-6f));
}

void OneClicMasterAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty ("customLogoPath", customLogoPath, nullptr);
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void OneClicMasterAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName (apvts.state.getType()))
    {
        auto tree = juce::ValueTree::fromXml (*xmlState);
        customLogoPath = tree.getProperty ("customLogoPath", "").toString();
        apvts.replaceState (tree);
    }
}

juce::AudioProcessorEditor* OneClicMasterAudioProcessor::createEditor()
{
    return new OneClicMasterAudioProcessorEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new OneClicMasterAudioProcessor();
}
