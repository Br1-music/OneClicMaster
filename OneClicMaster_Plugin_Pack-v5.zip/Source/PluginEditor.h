#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class OneClicMasterAudioProcessorEditor : public juce::AudioProcessorEditor,
                                          private juce::Timer
{
public:
    explicit OneClicMasterAudioProcessorEditor (OneClicMasterAudioProcessor&);
    ~OneClicMasterAudioProcessorEditor() override = default;

    void paint (juce::Graphics&) override;
    void resized() override;
    void timerCallback() override;
    void mouseDown (const juce::MouseEvent& event) override;

private:
    void loadCustomLogoFromFile();

    OneClicMasterAudioProcessor& audioProcessor;

    juce::Image brandLogo;
    juce::Rectangle<int> logoBounds { 36, 14, 44, 44 };
    std::unique_ptr<juce::FileChooser> logoFileChooser;

    juce::ComboBox presetSelector;
    juce::TextButton oneClicButton { "ONE CLIC MASTER" };
    juce::Slider intensitySlider;
    juce::Label statusLabel;

    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> presetAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> masterActiveAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> intensityAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (OneClicMasterAudioProcessorEditor)
};
